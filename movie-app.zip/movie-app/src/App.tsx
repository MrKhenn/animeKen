import React, { useState } from 'react';
import "./App.css";
import MovieList from './components/MovieList';
import Header from './header';
import Footer from './fooster';

const App: React.FC = () => {
  const [movies] = useState([
    {
      id: 1,
      title: "My Hero Academy",
      genre: "Accion, Luchas",
      image: "imagen 1.jpg",
    },
    {
      id: 2,
      title: "Dan Da Dan",
      genre: "Misterio, Romance",
      image: "images 2.jpeg",
    },
    {
      id: 3,
      title: "Nanatsu No Taizai",
      genre: "Accion, Comedia",
      image: "images 3.jpeg",
    },
    {
      id: 4,
      title: "Fire Force",
      genre: "Accion, Suspenso",
      image: "images 4.jpeg",
    },
    {
      id: 5,
      title: "Jujutsu Kaisen",
      genre: "Misterio, Luchas",
      image: "images.jpeg",
    },
    {
      id: 6,
      title: "Dragon Ball Daima",
      genre: "Accion, Luchas",
      image: "imagen 8.webp",
    },
    {
      id: 7,
      title: "Kaiju N.8",
      genre: "Accion, Comedia",
      image: "Kaiju_No8_Key_Visual_2.webp",
    },
    {
      id: 8,
      title: "Re Zero",
      genre: "Romance, Accion",
      image: "imagen 6.jpg",
    },
    {
      id: 9,
      title: "Black Clover",
      genre: "Fantasia",
      image: "imagen 7.jpg",
    },
    {
      id: 10,
      title: "Pokemon",
      genre: "Fantasia",
      image: "imagen 5.jpg",
    },
  ]);

  return (
    <>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <div className="app">
      <Header />
      <div className="app-container">
        <h1 className="app-title">🌀 Anime List 🌙</h1>
        <MovieList movies={movies} />
      </div>
      <Footer />
    </div>
    </>
  );
};

export default App;
