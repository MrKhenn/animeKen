import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <p>© 2024 AnimeKen. Todos los derechos reservados. Hecho por Kheynner Angulo</p>
      <div>
        <a href="#privacy">Política de Privacidad</a> | 
        <a href="#terms">Términos de Servicio</a>
      </div>
    </footer>
  );
};

export default Footer;
